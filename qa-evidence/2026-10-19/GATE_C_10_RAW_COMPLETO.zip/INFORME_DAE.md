# LINGORA — Informe AE para DAE · 19/10/2026
ESTADO: GATE C FAIL; SEEK NO CERTIFICADO
SHA: 08fa9c5e4d993c1d574760c3e2461f6c013a1cc4
DEPLOYMENT: dpl_4z4HRNChUSyM2XtHqEHeigWtJNgd (SHA confirmado, READY)
PROTOCOLO PREREGISTRADO CEO: https://github.com/lingora-labs/lingora/pull/14#issuecomment-6271097165
PR: https://github.com/lingora-labs/lingora/pull/14 · main intacto

## GATE C — Única batería, diez solicitudes, ninguna sustituida
- Quiz táctil completo: 9/10 (objetivo 10/10): FAIL.
- Autocorrección: 8/10 (objetivo CEO 100 %, 10/10): FAIL.
- PDF / imágenes no solicitados: 0/10.
- Claves automáticas incorrectas detectadas en revisión gramatical manual AE: 0/24. No es revisión institucional IJL.
- EXPLICACIONES PEDAGÓGICAS ERRÓNEAS: intentos 1,3,8 y 10 dicen que «Madrid ___ en España» usa SER, pese a que la opción calificada es «está». Intento 2 tiene explicación contradictoria y auto-corrección en el propio texto.
- Intento 5: dos cierres bad_subject:0 y fallo stream fatal, sin quiz y con artifactFailures.
- Intento 7: quiz táctil válido para revisión; gradingMode=tutor_review tras revisión semántica estructuralmente inválida; el sistema preservó el quiz, como exigió DAE.

| # | HTTP | Quiz | gradingMode | Causas | Request ID | SHA-256 SSE |
|---:|---:|---:|---|---|---|---|
| 1 | 200 | 1 | auto | - | iad1::iad1::lwq9x-1792424441157-3f0805f0f934 | 3fcd2ad5a4e212309c89f1bb5f9d04d814210ba69001615ebe12085720a4cc06 |
| 2 | 200 | 1 | auto | - | iad1::iad1::xjxfx-1792424447943-826e08b08b2c | 62a516a479fc95d41b9e1b7d7a9e4f14334114b14d85118838fb7f1d849f66c8 |
| 3 | 200 | 1 | auto | - | iad1::iad1::g59l5-1792424450890-32ac6c39512d | 165ae461a7fc9c935dc10f1e8f3fb3a8584d2bc0fa73b59981fbdb3b5646b5e0 |
| 4 | 200 | 1 | auto | - | iad1::iad1::r4csm-1792424458029-21ac721274cb | 92f33e7616ea94b3978517296229f92c4010f026bab01bc408cc28a6fd876bee |
| 5 | 200 | 0 | sin quiz | artifactFailures, quiz_count_0, question_count_null | iad1::iad1::6wjwk-1792424463282-39e46be10831 | ca10b2909cde8980fa5c1f168bfd33083b216da1a72a9469c5987af380e8f60b |
| 6 | 200 | 1 | auto | - | iad1::iad1::5vdh7-1792424467361-c36f97e283d1 | 9ad483963521dad6df30a4c908e686ae774cfcd9c661cb42f8461cbe40cfc569 |
| 7 | 200 | 1 | tutor_review | tutor_review_not_auto | iad1::iad1::jpk28-1792424471700-e3922600f5bc | 6368aad336a365ce0a2acaccea763298d4657490e1a5e4fe91037aec07d41a64 |
| 8 | 200 | 1 | auto | - | iad1::iad1::2mfd8-1792424475949-8dec3bf314f2 | 452d9610b8783418c0d8bd318583d320dc0c152f2eaecb0ef3ee2e59d5727a70 |
| 9 | 200 | 1 | auto | - | iad1::iad1::bmmp4-1792424480567-10116b5253e1 | 45eb35e1ae11bf320651d26d5ea6e362edf8572a75a893ae2b20f1895b457a3d |
| 10 | 200 | 1 | auto | - | iad1::iad1::mwbzc-1792424485509-36cbd662e75f | d90bd75566bdee8f811dbff95359d411700eb096226a3c9990b9f1e99c0c72e3 |

## Revisión lingüística preliminar independiente del código
AE verificó las opciones marcadas de los 24 ítems auto-calificables con criterio de gramática española; no utilizó validateQuizAnswerKey como arbitraje.
En estos 24 ítems no se observó un índice erróneo, pero el texto pedagógico contradice la clave en múltiples casos. En intento 3, el índice indica «está» y la explicación dice «La ubicación geográfica se expresa con SER en este caso: Madrid es en España».
Los logs correlacionados [quiz-quality] registran incorrect_model_answer_key:1 en esos turnos. Causa estructural probable: materializeNativeArtifact corrige el índice pero deja una explicación de modelo incompatible.
Se necesita revisión independiente IJL/Work para certificar; esto es análisis AE.

## Otros P1 — nuevas pruebas de API sobre el mismo SHA (NO UI)
### P1-01-first
HTTP 200 · completed=True · requestId=iad1::iad1::2mfd8-1792424915703-970073f4ca83
Respuesta: 445 caracteres; artifactTypes=; failures=[]

### P1-01-followup
HTTP 200 · completed=True · requestId=iad1::iad1::8knff-1792424918336-8a52350f531c
Respuesta: 222 caracteres; artifactTypes=; failures=[]

### P1-03-pdf-html-arabic
HTTP 200 · completed=True · requestId=iad1::iad1::f9vjv-1792424919379-a2a819267079
Respuesta: 5900 caracteres; artifactTypes=; failures=[{"subject": "SER y ESTAR (PDF y HTML no disponibles)"}]

### P1-04-export-chat
HTTP 200 · completed=True · requestId=iad1::iad1::c54p4-1792424941010-18a287b10a3f
Respuesta: 64 caracteres; artifactTypes=pdf_chat; failures=[]

### P1-05-arabic-explanation
HTTP 200 · completed=True · requestId=iad1::iad1::htzsj-1792424944064-fd4daaa24a7c
Respuesta: 1170 caracteres; artifactTypes=; failures=[]


P1-01: PASS diagnóstico API; Laura, auxiliar de enfermería, examen español A2 el viernes se recuerdan exactamente.
P1-03: FAIL; texto extenso entregado pero ni PDF ni HTML, artifactFailures: SER y ESTAR (PDF y HTML no disponibles). No se infiere causa del ejecutor sin logs.
P1-04: PDF real de exportación pdf_chat, 66.572 bytes, SHA256 a489ba2eb2dda8b6796f59e2a9e8adb4aec9dd129ca5bef739206d7cc7266598; PDF-1.4, %%EOF. Inspección literal/visual adicional necesaria.
P1-05: respuesta en árabe 621 caracteres árabes, ejemplos en español, sin artifacts ni fallos en prueba sintética API; no igual al antiguo prompt Work.
Imagen: NO RETESTED; autorización DAE específica pendiente.
Audio: NO TESTED, requiere evaluación humana.

## Gobierno de evidencia
- Incluye diez respuestas raw SSE, hashes, respuestas parseadas, failures, códigos, prompts, pruebas sintéticas P1 y PDF exportado.
- El HTTP 200 no certifica producto. No se ha probado experiencia real Chromium ni IJL/Work.
- Sin cambios de código, nuevo SHA, merge o modificación de main.
- Histórico 4/10 del SHA anterior intacto; SEEK 89,90/90 NO CERTIFICADO.
SEMÁFORO: ROJO Gate C, ROJO PDF+HTML, AMARILLO otros P1 API, ROJO SEEK.
Firmado: Ingeniería de Soporte — LINGORA · Para revisión de DAE.
